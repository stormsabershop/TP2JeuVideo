using UnityEngine;

public class PowerUp : MonoBehaviour
{
    public enum PowerUpType
    {
        IncreaseSize,
        BouncyPhysic
    }

    public PowerUpType type = PowerUpType.IncreaseSize;
    public float duration = 6f;
    public float rotationSpeed = 60f;

    private void Update()
    {
        // little spin for visibility
        transform.Rotate(Vector3.up, rotationSpeed * Time.deltaTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            var player = other.GetComponent<PlayerController>();
            if (player != null)
            {
                player.EnablePowerUp(type, duration);
                
            }
            Destroy(gameObject);
        }
    }
}
